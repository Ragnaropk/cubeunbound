CUBE UNBOUND MOD KIT (for free Alpha 0.2.3.1 and paid 0.5.2.1)
==============================================================

With this kit you make mods without coding and without touching the game folder
by hand: you create your mod, change it with fields, the kit checks it the way
the game would read it, installs it and removes it leaving everything as it was.


GETTING STARTED
---------------
1. Unzip the kit anywhere. Easiest: next to the game folder, for example both
   in Downloads.
2. Open KitMods.exe. If it can't find the game by itself, it asks you to pick
   the game folder (the one with CubeUnbound.exe) and remembers it.
   If Windows says "Windows protected your PC", press "More info" and then
   "Run anyway" (it shows up with downloaded programs that aren't signed,
   like the game itself).
3. Press "Create a new mod" and give it a name. Your mod already comes with
   things that work:
     - a creature (Ash Boar, in savannas and deserts),
     - a weapon with its own model (Ash Sword, made at the anvil),
     - a food (Boar Stew, made at the campfire),
     - a horde and a dungeon (The Ash Crypt),
     - and English names for all of it.
4. Press "3. Install" and then "4. Play" to see it in the game.
5. Press "1. Edit my mod" and change it as you like with fields. Then press
   "3. Install" again to bring the changes into the game.

The kit speaks English when Windows is not in Spanish. The game's own data is
written in Spanish; the editor has an "English name" field for everything.


FREE AND PAID
-------------
The kit works with both: Alpha 0.2.3.1 (free) and Alpha 0.5.2.1 (paid). It reads
your CubeUnbound.exe's version and checks with that same version's code, so what
it tells you is what that game would say. The top of the window shows which one
you're working for.
  - If you have both, "Change game…" lets you pick with one click.
  - Each mod records which version it was made for. If you check on the free one
    a mod made for the paid one (or the other way round), it warns you: anything
    it names that doesn't exist in that game shows up as an error.
  - "Game settings" also shows the files only the paid one has (alchemy, clans,
    bestiary, dialogue, weather by biome...) when it's the one selected.
  - The free and the paid versions don't play together on LAN, with or without
    mods.


THE FOUR STEPS
--------------
  1. Edit my mod      The editor: change your mod with fields and lists,
                      without opening any file (see below).
  2. Check            Loads your mod with your version's code, without
                      installing anything, and tells you what's wrong and
                      what to do.
  3. Install          Copies your mod into the game's mods folder.
  4. Play             Starts the game (if there are changes not yet
                      installed, it asks first).

And also:
  Create a new mod           Copies the template with your mod's name.
  Add a downloaded mod       Copies a mod someone gave you into your mods: its
                             .zip as it is or its folder (you can also drag the
                             .zip or the folder into the window).
  Share (.zip)               Makes a .zip of your mod in the kit's
                             para_compartir folder, ready to upload.
  Remove from game           Deletes what the mod installed and restores any
                             game files it had replaced. Your mod stays in
                             mis_mods.
  Open its folder            Your mod's files, for whoever wants to edit them
                             by hand.
  Rename…                    Your mod's name, author, version and one-line
                             summary; if it isn't installed, its folder name
                             too.


THE EDITOR
----------
On the left, what your mod has: items, recipes, creatures, hordes, dungeons
and races. Pick one and change its fields on the right. It saves itself when
you pick something else or close (or with "Save").

  Items       name (also in English), icon color, model; for weapons, the
              damage, reach and how they hit; for foods, what they heal.
  Recipes     what they make, how many, where (anvil, campfire...) and with
              which ingredients.
  Creatures   name and description, whether they attack or run away, health,
              damage, level, speed, which biomes they live in, how many show
              up and what they drop.
  Hordes      which creatures make up the horde and how many of each.
  Dungeons    style, enemies, boss, level, floors, rooms, distance from spawn,
              biomes and the blocks of their walls, floor and light.
  Races       name and description (also in English), health, damage, armor,
              speed, their traits (swimming, jumping, holding breath...) and
              their voxel size.

"+ Add…" creates new things: a weapon or a food (with its recipe), a material,
a recipe, a creature (copying the look of one from the game), a horde, a
dungeon or a race. "Delete" removes the selected one.

A NEW RACE
"+ Add…" → "Race" copies a race from the game (the one you pick) under another
name: its .vox models, its colors and its skill tree, all inside your mod.
Then change its numbers in the editor, its models with MagicaVoxel (in
mods\models\<your mod>\<the race>) and its skills in mods\skills\<the race>.json.
It shows up on the character creation screen with its name. Note: in Alpha
0.2.3.1 and 0.5.2.1 that screen doesn't show a new race's description yet; it
comes in the next version of the game (your mod already has it, nothing to do).

When you close the editor, the kit checks your mod by itself and tells you if
the game accepts it. What the editor doesn't show (a creature's parts,
effects...) is kept as it is; whoever wants to touch it has "Open its file".


GAME SETTINGS
-------------
Below your mod's things, the editor has the whole game:

  Game settings              The most wanted ones, by name: day and night,
                             danger by distance, weather, ores, starting stats,
                             dying, the starting kit, combat, experience and
                             max level, hordes, prices, rarities,
                             achievements...
  Everything in the game     Every data file of the game: creatures, items,
  (advanced)                 races, skills, furniture, farming, fishing,
                             vehicles...

Each file shows as a table: the setting, its value, its English text (if it
has one) and what it is in the game. Double-click a value to change it;
right-click to put back the game's value, or to duplicate, add or delete
entries in a list. What you change shows in blue and saves itself.

Your mod carries its own copy of each file you change, and installing it
replaces the game's (removing it brings the game's back). If a file ends up as
in the game again, your mod stops carrying it; "As in the game" does that in
one go. Two mods can't change the same file at the same time.

Texts have two boxes: Spanish (the file) and English (what English players
see, stored in your mod's mods\lang\en\).

WORLD SHAPE AND SIZE (special maps)
In "Game settings" → "World" → "World shape and size":
  Shape            normal, island (land up to its radius and sea around) or
                   flat (everything at the same height, no rivers or
                   mountains).
  World edge       how many km from spawn the abyss begins (62 by default).
                   With 2 or 3 km you get a small map.
  Far zones        zones at a fraction of their distance: with 0.05, the rare
                   biomes, danger, ores and dungeons from far away show up a
                   few hundred meters out.
  Relief, biome size, warmer or colder, wetter or drier.
  Caves, villages, cities, roads, structures and dungeons: on or off.
It applies to what the game generates: make a new world. It needs Alpha 0.2.1
from October 19, 2026 or a later one (the check warns you if yours is older), and on
LAN everyone with the same mod.


WHAT THE CHECK TELLS YOU
------------------------
  Error     The game will skip that (an item, a recipe, a creature...). Below
            it, in gray, the kit tells you what to do.
  Warning   It works, but maybe not as you expect: a file in a folder the game
            doesn't read...
  Note      Information (for example, which game files your mod changes).

Errors are the same ones the game writes on startup to informes\registro.txt
(some in Spanish, as the game writes them). The kit also warns about things
the game keeps quiet: dungeons with errors, a horde or a boss that doesn't
exist, and missing models.


WHAT A MOD LOOKS LIKE
---------------------
  mis_mods\
    my_mod\
      mod.json        Name, author, version (the game doesn't read it).
      LEEME.txt       What your mod brings.
      mods\           Same layout as the game's mods folder:
        items\        items              mobs\          creatures
        recipes\      recipes            horde\hordes\  hordes
        dungeons\     dungeons           models\        .vox models
        races\        races              skills\        skill trees
        lang\en\      English translation

To edit by hand: .json files open with Notepad (FIELD_GUIDE.txt explains every
field) and .vox models with MagicaVoxel. Always use your mod's prefix in ids
and file names; the editor already does it for you.


INSTALLING AND REMOVING
-----------------------
Installing copies your mod's mods\ files into the game's mods folder and
records what it copied in <game>\mods_instalados\. If your mod replaces a game
file, it keeps a copy first. Don't delete mods_instalados: "Remove from game"
uses it to leave the game exactly as it was.

The game reads mods on startup: if it was open, close it and start it again.
On LAN, every player must have the same mods installed.


SHARING YOUR MOD
----------------
Press "Share (.zip)": the kit makes the .zip in the para_compartir folder and
opens it for you. Upload it anywhere. Whoever downloads it drags the .zip into
their kit window (no need to unzip it), then "3. Install".
If you play together on LAN, everyone needs the same mods installed.

Mod guide and tutorials: https://ragnaropk.github.io/cube-unbound-wiki/tutoriales.html
