CUBE UNBOUND · Alpha 0.2.5 for Linux (x86_64)
================================================

A voxel RPG on its own engine: explore, fight, find loot with rarities, level up, build,
tame mounts, trade and play with friends over LAN. It is an alpha: things are missing and
there will be bugs. Thanks for playing it!

The game is in English and Spanish. It picks your system language; you can change it in
Options > Language.

HOW TO START
------------
1. Unpack this folder wherever you like (nothing to install).
2. Run ./CubeUnbound (if it doesn't start, give it permission: chmod +x CubeUnbound).
3. Optional: ./instalar_acceso_directo.sh adds the game to your applications menu
   (./desinstalar_acceso_directo.sh removes it).

Requirements: a desktop with X11 or Wayland (through XWayland), OpenGL 3.3 (any graphics card
from the last 12 years with its drivers) and ALSA for sound (PulseAudio and PipeWire provide it).
Built with glibc 2.35: that version or newer (Ubuntu 22.04, Mint 21, Debian 12,
Fedora 36 or later). On an older one you only get "GLIBC_2.3x not found".

WHERE IT SAVES
--------------
Everything stays inside this folder: saves/ (worlds), characters/, settings.json (options),
screenshots/ and informes/ (the log of each session and crash reports). To back up your game
or move it to another PC, copy the whole folder.

PLAYING OVER LAN (same network)
-------------------------------
Whoever opens the game: "Host a LAN game" in the menu (or H inside your world). The others:
"Join a LAN game" and pick the game from the list, or type its IP. Windows, Android and Linux
play together. Everyone needs this same version (Alpha 0.2.5) and the same mods/ folder.

DEDICATED SERVER
----------------
./servidor.sh runs the game as a server, with no window. See LEEME_SERVIDOR.txt (in Spanish).
Console commands: list, say <text>, save, kick <name>, stop, help.

IF SOMETHING GOES WRONG
-----------------------
- If the game crashes, next time it opens it tells you: there is a report in informes/
  (fallo_<date>.txt). Send it to us, along with informes/registro.txt.
- If it runs slowly: Options > Graphics quality > Minimal or Low, and lower the view distance.

News and support: https://cubeunbound.com/

WHAT'S NEW IN 0.2.5
-------------------
0.2.5 is the biggest update of the free version: full evolutions, villages of all 10 races, the 13 reserved bosses
with their colossal dungeons, 80 new creatures, upgrades from +0 to +20, new music and three world difficulties. It
also fixes what you told us on Discord after 0.2.4.3. Thanks to everyone who reported and to everyone supporting
the game. Your 0.2.4.3 worlds and character open in 0.2.5 without losing anything.

New:
- World difficulty, chosen when you create it: Novice (weaker and fewer monsters), Adventurer (the usual game, with
  slower health regeneration; your old worlds are Adventurer) and Dark Cube (monsters with x1.5 health and x2
  damage, twice as many enemies, no regeneration, everything goes to the grave when you die and no minimap). In LAN
  the host's difficulty rules.
- Full evolutions: all 150 forms, female ones too. Every 100 levels you choose a branch and your body changes, and
  your armour, weapons, mounts, vehicles, wings, tools, dances, skin and pets fit it. The healer undoes an
  evolution for a good sum.
- The 18 branch weapons, which arrive at evolution 100 and awaken later.
- Villages mixing buildings of the 10 races by biome, with their guards (crimes, fines and "wanted"), the
  innkeeper, the stablemaster and the healer, chests and furniture you can take. Far-away villagers sleep.
- Upgrades from +0 to +20 with gems (Blessing, Soul and Chaos): drop the gem on the piece. If it fails, it wears
  and drops a level; from +15 it no longer drops, it only cracks.
- The pet whistle (2 sticks + 1 string): right click to store or bring out your pet.
- The pocket watch, the pedometer and the coordinate compass, in the altimeter panel.
- The 13 reserved bosses (Kharra, Orichalcum Poseidon, the Automaton Dwarf King, Zephyros, Ouroboros, Karybdis,
  Thor'Kael, Ankhor, the Abyssal Behemoth, Aethelgard, the Genesis Kraken, the Origin Golem and the Demiurge) in
  14 colossal dungeons, and 8 boss dungeons: the Mother Oak, the Aurora Den, the Storm Nest, the Hollow Dune Sea,
  the Magnetic Quarry, the Living Forge, the Sunken Sanctuary and the Jötunn Hall.
- Bosses no longer spawn at random: each one waits in its dungeon, with animated attacks that warn you and breaking
  the room. Raids bring unique enemies. 39 achievements, one per boss. Improved new dungeons.
- 80 new creatures around the world and more wildlife in poor biomes.
- Physics: sand and gravel fall, fire spreads and burns out, and creatures push each other.
- Lively animations for characters and creatures: they breathe, look around, drink, climb, splash...
- New music in 10 biomes, without the click when a track starts again.
- /op (operator) and /volar si|no. Block and report players, and the chat rules.
- Accessibility: the name of what you are looking at under the crosshair and a colour-blind mode.

Fixes:
- Monsters no longer stop spawning after playing for a long time or travelling far.
- Bosses, uniques and raids no longer vanish with /tp, pause or quitting.
- Water no longer hangs or turns invisible. The sky no longer turns white with the Solar Halo.
- Kill experience is capped: passive animals give a fifth, guards very little and no monster raises you more than
  4 levels at once.
- You no longer pick anything up while dead. Fences now block, monsters too.
- Magic is balanced. A new world starts calm: the new enemies don't spawn next to the start.
- More sight underwater: the brass diving helmet (+16 m), the orichalcum diving suit helmet (+40 m) and the reef
  sashimi (+50 m for 12 minutes).
- About 30 more fixes to saving, network, inventory, dungeons and graphics.
- The network version changes: everyone needs 0.2.5 (and its mods folder) to play together.
