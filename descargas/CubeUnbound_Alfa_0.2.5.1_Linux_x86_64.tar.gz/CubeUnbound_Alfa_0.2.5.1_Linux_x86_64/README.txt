CUBE UNBOUND · Alpha 0.2.5.1 for Linux (x86_64)
================================================

A voxel RPG on its own engine: explore, fight, find loot with rarities, level up, build,
tame mounts, trade and play with friends over LAN. It is an alpha: things are missing and
there will be bugs. Thanks for playing it!

The game is in English and Spanish. It picks your system language; you can change it in
Options > Language.

HOW TO START
------------
1. Unpack this folder wherever you like (nothing to install).
2. Run ./CubeUnbound (if it doesn't start, give it permission: chmod +x CubeUnbound).
3. Optional: ./instalar_acceso_directo.sh adds the game to your applications menu
   (./desinstalar_acceso_directo.sh removes it).

Requirements: a desktop with X11 or Wayland (through XWayland), OpenGL 3.3 (any graphics card
from the last 12 years with its drivers) and ALSA for sound (PulseAudio and PipeWire provide it).
Built with glibc 2.35: that version or newer (Ubuntu 22.04, Mint 21, Debian 12,
Fedora 36 or later). On an older one you only get "GLIBC_2.3x not found".

WHERE IT SAVES
--------------
Everything stays inside this folder: saves/ (worlds), characters/, settings.json (options),
screenshots/ and informes/ (the log of each session and crash reports). To back up your game
or move it to another PC, copy the whole folder.

PLAYING OVER LAN (same network)
-------------------------------
Whoever opens the game: "Host a LAN game" in the menu (or H inside your world). The others:
"Join a LAN game" and pick the game from the list, or type its IP. Windows, Android and Linux
play together. Everyone needs this same version (Alpha 0.2.5.1) and the same mods/ folder.

DEDICATED SERVER
----------------
./servidor.sh runs the game as a server, with no window. See LEEME_SERVIDOR.txt (in Spanish).
Console commands: list, say <text>, save, kick <name>, stop, help.

IF SOMETHING GOES WRONG
-----------------------
- If the game crashes, next time it opens it tells you: there is a report in informes/
  (fallo_<date>.txt). Send it to us, along with informes/registro.txt.
- If it runs slowly: Options > Graphics quality > Minimal or Low, and lower the view distance.

News and support: https://cubeunbound.com/

WHAT'S NEW IN 0.2.5.1
---------------------
0.2.5.1 polishes 0.2.5: the real Dark Cube, what you asked for on Discord, and lots of fixes. Thanks to everyone who
reported and to everyone supporting the game. Your 0.2.5 worlds and character open in 0.2.5.1 without losing
anything. Online, 0.2.5.1 doesn't mix with 0.2.5: everyone has to update.

New:
- The real Dark Cube (only in Dark Cube worlds): dodge with Shift (a roll where you can't be hit), parry and
  riposte with a well-timed right click (an open enemy takes triple damage), every attack is telegraphed, lock on
  with I, sap flasks, the travel map, the Menhir as a resting altar and your echo: your experience stays where you
  fall and you get it back by touching it. Online too.
- Your character is bound to Dark Cube and keeps signed ranking data.
- Exact damage numbers in PvP.
- "Where you died" on the map. Your grave puts everything back in its place (backpack items into the backpack).
- Bosses and uniques break blocks and villages while chasing you, never what players build; villages repair
  themselves in a day. Knockback no longer pushes them away. "bossesBreakBlocks": false in servidor.json turns it
  off.
- The bounty board tells you how long until uniques appear, and the wait drops from 45 to 15 minutes.
- The Thief Octopus, the Pickpocket and the Gull steal and the Owl dazzles, as their card says; they drop what they
  stole when they die.
- All 30 branches have their weapon: the 12 missing ones are here.
- The crate, the cactus, the dwarf pillar and the cobalt beam, with their models.
- "Review" in the Mods menu.
- Lighter on Windows: meshes take less graphics memory, less stutter when flying, and terrain loads where you look
  first.

Fixes:
- Quitting the game in mid-air no longer saves you from the fall: you come back where you were, still falling.
- Rugs, torches, things hanging from the ceiling and flat wall decorations are no longer an invisible block.
- You can reach the boss of the Jötunn Hall, the Storm Nest and the Ether Crater (in your old worlds too).
- Dungeon bosses can no longer be farmed. Uniques no longer spawn twice or inside rock. Bosses and big creatures
  are visible from afar. Bounties wake up again.
- Online, creatures no longer "lag" on a bad connection.
- The sculpting forge no longer leaves a weapon bare. A grave with a backpack is picked up in one go. Crafting only
  uses common materials. The alchemy Cauldron can no longer be crafted (it did nothing).
- An unconscious pet no longer gains experience. /reportar is saved to a .txt to send on Discord.
- Texts that showed in Spanish with the game in English, and more save, network and interface fixes.
