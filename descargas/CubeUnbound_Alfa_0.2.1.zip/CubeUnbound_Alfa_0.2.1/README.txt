CUBE UNBOUND · Alpha 0.2.1
==========================

A voxel RPG on its own engine: explore, fight, find loot with rarities, level up,
build, tame mounts, trade and play with friends over LAN.

This is an alpha: things are missing, there will be bugs and the numbers are still
being tuned. Thanks for playing it!

The game is in English and Spanish. It picks your Windows language; you can change it
in Options > Language.

WHAT'S NEW IN 0.2.1
-------------------
- English: menus, items, creatures and the guide (Options > Language).
- Chat: Enter to type, Enter to send. Messages show at the bottom left and in a bubble
  over the speaker's head. Hold Z for the sticker wheel. In servidor.exe, "say <text>".
- On LAN and with servidor.exe, creatures killed by a player who joined now fall to pieces
  at once (they used to stand for about 2 seconds). Best if everyone has this version.
- Special maps with mods: a mod can change the world's shape (island, flat, a small world
  with an edge, far zones closer, relief, climate, no caves or no villages) with
  mods/world/generation.json. The mod kit on the website does it without writing anything.
- A loading screen when the game starts: it no longer shows "Not responding" the first
  time, which is when it takes longest.
- Survival mode: you start with nothing. Tools, weapons and staves are found or crafted.
- The mouse wheel changes slot, like in Minecraft. Ctrl + wheel zooms the camera.
- Runs on Windows 7 SP1 and 8.1 too.
- The map is no longer mirrored: north up, east right. Map and minimap show N, S, E and W.
- Dungeons appear on the map when you pass near their entrance.
- Trash slot in the inventory, under the shield; the last thing thrown away can be
  recovered with a click.
- A lantern in your hand lights up around you (also in the off hand: Shift+click).
- Falling hurts less: up to about 5 blocks there is no damage.


HOW TO START
------------
1. Unzip the folder wherever you like (nothing to install). Use "Extract all":
   don't run the game from inside the zip.
2. Open CubeUnbound.exe.
3. "Character" to create yours and "Play" to start a world.
   The guide on the right tells you what to do in the first minutes.

Requirements: 64-bit Windows 7 SP1, 8.1, 10 or 11 and a graphics card with DirectX 11
or OpenGL 3.3. The first time, the game picks the graphics quality for your card;
change it in Options (Low if your PC struggles).


KEYS (change them in Options)
-----------------------------
  W A S D        walk               Space      jump (and open the glider in the air)
  Shift          run                Ctrl       crouch (to tame, with its food)
  Left click     hit / mine         Right click eat, charge the staff, use
  Tab            inventory and crafting        E   place / use (chests, beds, board, merchant)
  1-9            slots              Q          drop what you hold
  N              skill tree         R          mount or dismount
  M              map                J          codex (journal, achievements and titles)
  U              show or hide the guide        O   open your market stall
  Enter          chat               Z          sticker wheel (hold)
  T              rotate furniture   V          first or third person
  F5             save               F12        screenshot
  Esc            pause and options


WHERE IT SAVES
--------------
Everything stays inside this folder:
  saves\         worlds
  characters\    characters
  settings.json  options
  screenshots\   screenshots
  informes\      the log of each session and crash reports
To back up your game or move it to another PC, copy the whole folder.


PLAYING OVER LAN (same network)
-------------------------------
- Whoever opens the game: "Host a LAN game" in the menu (or H inside your world).
- The others: "Join a LAN game" and pick the game from the list.
- Everyone needs this same version (Alpha 0.2.1) and the same mods\ folder.
- Windows Firewall may ask the first time: allow private networks.


DEDICATED SERVER (servidor.exe)
-------------------------------
- servidor.exe runs the game as a server: no game window, just a console.
- The first time it asks for the world, the number of players (up to 7), the password
  (can be empty), the difficulty and PvP. Answers are kept in servidor.json.
- Console commands: list, say <text>, save, kick <name>, stop, help.
- Over the internet, forward UDP port 27015 to the server PC, or use a virtual network
  (Radmin VPN, ZeroTier).


IF SOMETHING GOES WRONG
-----------------------
- If the game crashes, next time it opens it tells you: there is a report in the
  informes\ folder (fallo_<date>.txt and .dmp). Send it to us.
- If something is off but the game keeps running: Esc > "Report a bug". It saves a
  screenshot, the log and your game in informes\informe_<date>\.
- If it runs slowly: Options > Graphics quality > Low, and lower the view distance.
- If it doesn't start or the screen is black: Options > Graphics at startup > OpenGL
  (or F11 in game to try the other one).

Contact: Neurostudios.contacto@gmail.com
