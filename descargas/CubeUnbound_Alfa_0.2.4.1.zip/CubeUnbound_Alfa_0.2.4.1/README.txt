CUBE UNBOUND · Alpha 0.2.4.1
==========================

A voxel RPG on its own engine: explore, fight, find loot with rarities, level up,
build, tame mounts, trade and play with friends over LAN.

This is an alpha: things are missing, there will be bugs and the numbers are still
being tuned. Thanks for playing it!

The game is in English and Spanish. It picks your Windows language; you can change it
in Options > Language.

WHAT'S NEW IN 0.2.4.1
---------------------
0.2.4.1 is the stable version of the free game: no new content, but every stability, network and performance fix of
the paid one. Thanks to Meme, joaquin, CHAMANICOD, Fachan, Lagz and everyone who reported them. Your 0.2.4 worlds and
character open in 0.2.4.1 without losing anything.

Nothing gets lost any more:
- The explored map no longer empties when you enter the world again.
- Purchases between players go through a reliable channel: if the network drops or the seller leaves, the money
  comes back.
- Coins that don't fit fall to the ground; what you hold on the cursor is kept even with a full backpack; what doesn't
  fit in a grave goes into another one.
- No dungeon is impossible any more (the jailer's key behind a closed arena). If you were already stuck in one, the
  jailer's room opens again once, without loot.

Multiplayer and servers:
- Creatures hit guests with their real damage, and a nearly dead boss no longer becomes immortal.
- Everyone sees the bosses and the bear, the red ring of their leap, the raid and the meteor's shadow.
- Guests discover villages and structures, and see rarity and sculpting in shared chests.
- Village chests are no longer empty for guests, and what they drop far away no longer chases them.
- Creatures and villagers move smoothly for guests, and stop chasing whoever has left.
- H as host no longer closes the LAN. servidor.exe no longer plays music or closes abruptly without a window.
- Join: a tunnel (playit) uses the port you type, you can click the boxes, and if nobody answers it tells you why.
  The network version changes: everyone needs 0.2.4.1.

World:
- It no longer rains inside caves or houses.
- The village board and counters can't be carried off; meteors don't break chests or houses; a piece of furniture no
  longer erases the ladder or crop below it; emptied camps are remembered.
- Bosses no longer spawn in treetops, the raid boss chases and retreats, and the board doesn't ask for impossible
  hunts. Villagers of a hilltop village no longer spawn buried.
- More natural rivers: no floating water or water walls, and waterfalls now flow.

Interface and combat:
- No more double hits when switching items, and the item card no longer exaggerates penalties.
- Clicking a chest on narrow screens goes to the chest, the guide doesn't cover notices and falling doesn't play the
  combat music. "…" no longer shows as "?" and a new character doesn't inherit the bed of a deleted one.
- Screenshots no longer show the pause menu. The "Language" help says "the system language".
- Dances with Z (20: half the dances and gestures, and both poses) and a new-version notice in the menu.

Performance:
- Default quality based on your graphics card (an Intel UHD 600 starts on Minimal).
- Less CPU in forests, fish schools and hordes, no stutter entering a village and less with rails, crops and furniture.
- It starts on PCs with DirectX 10 graphics (2011 Intel HD 2000/3000). They are weak: use Minimal quality.
- Android: Minimal quality, battery mode (30 FPS) and a brake when the phone gets hot.
- Linux: "Creature distance", "Particles", "Clouds" and "Terrain loading", and Minimal is no longer half-lit.


WHAT'S NEW IN 0.2.4
-------------------
Improved servers (servidor.exe):
- Up to 30 players (it used to be 7): the server asks the first time, with 30 by default, and you can change it in
  servidor.json. A LAN game opened from inside the game still takes 8.
- On a server, your character is saved on the server: you start from scratch on each one (keeping your look and race)
  and what you earn there stays there. Your usual character is left untouched.
- Nobody can join with your name: the game creates an invisible key and the server remembers it (it lives in
  characters\). The server no longer draws the world in secret and uses half the CPU; closing its console or
  shutting down the PC saves, like "stop".

Performance (especially on modest PCs):
- New "Minimal" quality, below Low: shorter view distance, no corner shadows, minimal shading, fewer plants and the
  world at 75 %. What you can't see is no longer drawn (caves under the ground, whatever is behind a hill).
- New Graphics options: Corner shadows, Minimal shading, Plants and grass, Creature distance, Critters and fish
  schools, Particles, Clouds, Terrain loading and 3D world resolution.
- Calm, far-away creatures cost nothing, rain is lighter, saving no longer stutters and antivirus programs raise fewer
  false alarms.

Mods:
- "Mods" button in the main menu: enable, remove, share as .zip or delete your mods; a .zip dropped into mis_mods
  opens by itself. With "New mod" and "Edit" you make weapons, food, creatures, hordes, dungeons and races, no kit.
- Removing a mod no longer eats its items: they come back when you enable it again. Mod weapons can cast a spell on
  hit, and mod races show their description.
- The item card (rarity, properties, damage…) no longer disappears outside your backpack: it also shows in chests,
  when crafting, at merchants and at stalls.
- To test mods (with /cheats on): /spawn <creature> [level] [count] brings it out next to you, by its name or id, and
  /rarity <common|rare|epic|legendary|mythic> changes the rarity of what you hold.

A long game, everything in its zone:
- Gear and food from a zone above yours don't work until you're high enough ("you need level N"). Your zone comes
  from your level; merchants, taming and uniques also follow zones.
- Everything is worth what its zone is worth, and fishing and farming now pay; items from higher zones sell as if
  they were from yours, and crafted items never sell for more than their materials. Every enemy drops something.
- Real caps: shields block up to 85 % and cost stamina; killing something far above you no longer gives several
  levels at once, and neither board contracts nor half-fought dungeon rooms give endless XP.
- Each dungeon matches its zone's level and can't be dug through while the boss lives. If you die in a locked room,
  it reopens after 8 s and starts over.

Combat, movement and home:
- Hostile flyers attack, archers and mages shoot at close range, standing 2 blocks up no longer saves you and hits no
  longer go through walls. Bosses can't be frozen in a loop anymore and Khepri finally shows up. Plus dozens of fixes.
- Flying creatures no longer jump on top of a roof, bridge or overhang when passing underneath.
- Your character no longer walks and runs with frantic little steps, and moves a bit slower: walking 7.5 blocks/s and
  running 10.5 (8.5 and 12.75 before).
- 105 achievements in the codex (24 before): levels, bosses, uniques, dungeons, crafts, travel, boats, gems… When
  several unlock at once, you get a single notice.
- Smooth camera above 60 Hz, no longer clipping into walls. The hang glider no longer flies forever; mounted, you
  move at your mount's speed; boats and minecarts no longer get lost; saving mid-air puts you back on the ground.
- The basic fishing rod now fishes and picks the right bait. What lies on the ground is saved (also what you drop on
  death), and so are health and effects. Chests and workbenches no longer turn when you place something next to them.
- Rivers with waterfalls at ground level, and hostile wildlife no longer spawns within 96 blocks of a village.
- LAN: nobody can join with the name of someone already inside; nothing gets duplicated anymore (chests, graves,
  sculpted weapons); enemies no longer ignore guests, and XP goes to whoever damaged the creature.

Worlds and versions:
- Worlds from 0.2.3.1 and earlier don't open in this version, so they don't get broken (the list marks them).
  Characters do carry over: copy characters\ and settings.json from your old folder to this one.
- On LAN or a server, everyone on 0.2.4. For now it's Windows only: Android, Linux and Mac will follow, and until
  then mobile and PC players can't play together on this version.


WHAT'S NEW IN 0.2.3.1
---------------------
- Chests with loot: chests in villages, cities, camps, ruins and shipwrecks fill up the first time you open them, with
  items from that place and the zone's danger (further away, better loot, with rarity). They don't refill. Crypt
  chests in each dungeon also bring items found only there.
- Riding: R now mounts your pet even if it's a few steps away (before, standing still, it only said "Get closer").
  Next to a wild reindeer or horse, R tells you how to tame it.
- Boats are twice as fast; the sailboat no longer nearly stops against the wind.
- Keys no longer pile up: pressing O with the inventory open no longer opens the shop when you close it (same for
  any other shortcut).
- Your pet no longer pops up next to you while you glide, fly or ride a boat (it could knock you off the hang
  glider): it waits until you land.
- Tools in combat: hitting with a pickaxe, axe or shovel now goes at the pace of a fist (before they hit up to nine
  times as often, more than many swords). Mining blocks is as fast as before.
- Test keys (F3, F6, F7, F8 and F9) only work in developer mode and, on LAN, only for the host: before, anyone could
  push their gear to +20 with F7.
- Leaves placed next to dirt no longer let you see inside the ground.
- Seagrass and kelp can only be planted in water (outside they made water).
- Developer mode: the panel shows how far you are from the spawn point and the zone's danger.
- Worlds and characters from 0.2.3 work as they are. On LAN, everyone on 0.2.3.1.


WHAT'S NEW IN 0.2.3
-------------------
New:
- Torch: 1 stick + 1 coal make 4 (by hand). In your hand it lights up the area; press E to place it on the ground or
  next to a wall and it gives light. Stacks of 64.
- Flowing water: it spreads over the ground and runs down slopes. Bucket (anvil, 3 iron ingots): empty, right-click
  still water to fill it; full, right-click next to a block to pour it.
- Mining takes time: each block takes several hits depending on how hard it is and on your tool (a small bar under
  the crosshair shows your progress). A better pickaxe breaks faster. In creative, one hit.
- Chat commands (Enter and "/"): /help, /where, /seed and /cheats on. With cheats: /tp x y z (or bed, or spawn; "~"
  is where you are), /give item [n], /heal, /fly, /time, /weather and /creative. On LAN, for now only the host can
  use cheat commands.
- "Store all" in chests and wardrobes: moves your whole backpack into the chest (hotbar and gear stay).
- Player skins made in MagicaVoxel for the human: see mods/skins/LEEME.txt.
- Glass is see-through; the ladder has its own model against the wall.
- 49 more animals drop leather (fox, horse, lion, camel, sheep, mammoth...).

Fixed:
- Small screens (1024×768, narrow window): the crafting panel shows up again (and the bounty board and the
  merchant); the interface shrinks to fit.
- A boss health bar goes away after it has been far for a while (Ursa Major's stayed for hours).
- Uniques spawn at the zone's level (Tezcatl spawned at level 75 in zone 1); their usual level is the cap.
- The carriage no longer flies away.
- Pet names are accepted with Enter; you can ride it with R again and typing no longer triggers shortcuts.
- Bandits really defend their camp: they no longer turn back after a few blocks or ignore your hits.
- Combat music plays in real fights, not when hitting an animal or shooting into the air.
- Lanterns stack (before, one per slot) and no longer roll a rarity.
- LAN: a guest keeps their map of that world; someone who drops and rejoins no longer shows up twice; under the
  minimap you see which key closes the LAN (K).
- Discord with the game in English: the activity is fully in English.
- Worlds, characters and options from 0.2.2 work as they are. On LAN, everyone on 0.2.3.


WHAT'S NEW IN 0.2.2
-------------------
- FPS limit (Options > FPS limit: 30, 60, 90, 120, 144 or unlimited; 60 by default). Before, if the
  graphics driver or the desktop ignored vertical sync, the game drew as fast as it could: the GPU at
  100 % and the fans always on, especially on laptops and on Linux.
- With the window minimized or behind another one, the game drops to 15 FPS (30 on LAN) by itself.
- Laptops with two graphics chips (Intel + NVIDIA or AMD): the game uses the powerful one. Before it
  could stay on the integrated chip: low FPS and a lot of RAM used as video memory.
- If you pick Titan or Gods on integrated graphics, Options warns that it may run slowly.
- Discord: with Discord open, your profile shows that you are playing Cube Unbound, in which biome,
  with which race and level, solo or on LAN and for how long, with the "Download for free" and
  "Discord" buttons. Turn it off in Options > "Show activity on Discord".
- Poison, bleeding, burns and spell zones no longer drive creatures crazy: every frame used to count
  as a full hit (jerky movement, endless pain sounds, fleeing in random directions, zones throwing
  them far away). The damage is the same. On LAN, a player who joined sends that damage every half
  second instead of every frame.
- Worlds, characters and options from 0.2.1 work as they are. LAN works with 0.2.1, but it is best
  if everyone has 0.2.2.


WHAT'S NEW IN 0.2.1
-------------------
- English: menus, items, creatures and the guide (Options > Language).
- Chat: Enter to type, Enter to send. Messages show at the bottom left and in a bubble
  over the speaker's head. Hold Z for the sticker wheel. In servidor.exe, "say <text>".
- On LAN and with servidor.exe, creatures killed by a player who joined now fall to pieces
  at once (they used to stand for about 2 seconds). Best if everyone has this version.
- Special maps with mods: a mod can change the world's shape (island, flat, a small world
  with an edge, far zones closer, relief, climate, no caves or no villages) with
  mods/world/generation.json. The mod kit on the website does it without writing anything.
- A loading screen when the game starts: it no longer shows "Not responding" the first
  time, which is when it takes longest.
- Survival mode: you start with nothing. Tools, weapons and staves are found or crafted.
- The mouse wheel changes slot, like in Minecraft. Ctrl + wheel zooms the camera.
- Runs on Windows 7 SP1 and 8.1 too.
- The map is no longer mirrored: north up, east right. Map and minimap show N, S, E and W.
- Dungeons appear on the map when you pass near their entrance.
- Trash slot in the inventory, under the shield; the last thing thrown away can be
  recovered with a click.
- A lantern in your hand lights up around you (also in the off hand: Shift+click).
- Falling hurts less: up to about 5 blocks there is no damage.


HOW TO START
------------
1. Unzip the folder wherever you like (nothing to install). Use "Extract all":
   don't run the game from inside the zip.
2. Open CubeUnbound.exe.
3. "Character" to create yours and "Play" to start a world.
   The guide on the right tells you what to do in the first minutes.

Requirements: 64-bit Windows 7 SP1, 8.1, 10 or 11 and a graphics card with DirectX 11
or OpenGL 3.3. The first time, the game picks the graphics quality for your card;
change it in Options (Low if your PC struggles).


KEYS (change them in Options)
-----------------------------
  W A S D        walk               Space      jump (and open the glider in the air)
  Shift          run                Ctrl       crouch (to tame, with its food)
  Left click     hit / mine         Right click eat, charge the staff, use
  Tab            inventory and crafting        E   place / use (chests, beds, board, merchant)
  1-9            slots              Q          drop what you hold
  N              skill tree         R          mount or dismount
  M              map                J          codex (journal, achievements and titles)
  U              show or hide the guide        O   open your market stall
  Enter          chat               Z          sticker wheel (hold)
  T              rotate furniture   V          first or third person
  F5             save               F12        screenshot
  Esc            pause and options


WHERE IT SAVES
--------------
Everything stays inside this folder:
  saves\         worlds
  characters\    characters
  settings.json  options
  screenshots\   screenshots
  informes\      the log of each session and crash reports
To back up your game or move it to another PC, copy the whole folder.


PLAYING OVER LAN (same network)
-------------------------------
- Whoever opens the game: "Host a LAN game" in the menu (or H inside your world).
- The others: "Join a LAN game" and pick the game from the list.
- Everyone needs this same version (Alpha 0.2.4.1) and the same mods\ folder.
- Windows Firewall may ask the first time: allow private networks.


DEDICATED SERVER (servidor.exe)
-------------------------------
- servidor.exe runs the game as a server: no game window, just a console.
- The first time it asks for the world, the number of players (up to 30), the password
  (can be empty), the difficulty and PvP. Answers are kept in servidor.json.
- Console commands: list, say <text>, save, kick <name>, stop, help.
- Over the internet, forward UDP port 27015 to the server PC, or use a virtual network
  (Radmin VPN, ZeroTier).
- Each player's character is saved on the server (saves\<world>\jugadores\): they start from scratch
  there, and what they earn there stays there. If someone reinstalls the game and loses their key,
  delete their two files (.json and .clave) with the server closed so they can join with that name again.


IF SOMETHING GOES WRONG
-----------------------
- If the game crashes, next time it opens it tells you: there is a report in the
  informes\ folder (fallo_<date>.txt). Send it to us.
- If something is off but the game keeps running: Esc > "Report a bug". It saves a
  screenshot, the log and your game in informes\informe_<date>\.
- If it runs slowly: Options > Graphics quality > Low, and lower the view distance.
- If it doesn't start or the screen is black: Options > Graphics at startup > OpenGL
  (or F11 in game to try the other one).

Contact: Neurostudios.contacto@gmail.com
