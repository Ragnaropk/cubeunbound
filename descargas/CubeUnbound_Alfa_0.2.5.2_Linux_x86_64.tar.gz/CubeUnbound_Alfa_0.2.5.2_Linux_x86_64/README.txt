CUBE UNBOUND · Alpha 0.2.5.2 for Linux (x86_64)
================================================

A voxel RPG on its own engine: explore, fight, find loot with rarities, level up, build,
tame mounts, trade and play with friends over LAN. It is an alpha: things are missing and
there will be bugs. Thanks for playing it!

The game is in English and Spanish. It picks your system language; you can change it in
Options > Language.

HOW TO START
------------
1. Unpack this folder wherever you like (nothing to install).
2. Run ./CubeUnbound (if it doesn't start, give it permission: chmod +x CubeUnbound).
3. Optional: ./instalar_acceso_directo.sh adds the game to your applications menu
   (./desinstalar_acceso_directo.sh removes it).

Requirements: a desktop with X11 or Wayland (through XWayland), OpenGL 3.3 (any graphics card
from the last 12 years with its drivers) and ALSA for sound (PulseAudio and PipeWire provide it).
Built with glibc 2.35: that version or newer (Ubuntu 22.04, Mint 21, Debian 12,
Fedora 36 or later). On an older one you only get "GLIBC_2.3x not found".

WHERE IT SAVES
--------------
Everything stays inside this folder: saves/ (worlds), characters/, settings.json (options),
screenshots/ and informes/ (the log of each session and crash reports). To back up your game
or move it to another PC, copy the whole folder.

PLAYING OVER LAN (same network)
-------------------------------
Whoever opens the game: "Host a LAN game" in the menu (or H inside your world). The others:
"Join a LAN game" and pick the game from the list, or type its IP. Windows, Android and Linux
play together. Everyone needs this same version (Alpha 0.2.5.2) and the same mods/ folder.

DEDICATED SERVER
----------------
./servidor.sh runs the game as a server, with no window. See LEEME_SERVIDOR.txt (in Spanish).
Console commands: list, say <text>, save, kick <name>, stop, help.

IF SOMETHING GOES WRONG
-----------------------
- If the game crashes, next time it opens it tells you: there is a report in informes/
  (fallo_<date>.txt). Send it to us, along with informes/registro.txt.
- If it runs slowly: Options > Graphics quality > Minimal or Low, and lower the view distance.

News and support: https://cubeunbound.com/

WHAT'S NEW IN 0.2.5.2
---------------------
0.2.5.2 fixes what you found in 0.2.5.1 and brings what you asked for the most. Thanks to everyone who reported on
Discord and to everyone who supports the game. Your 0.2.5.1 worlds and character open in 0.2.5.2 without losing
anything. To play online, everyone should update.

New:
- While sneaking (Ctrl) you no longer fall off edges, like in Minecraft: you can lean out to the very last bit of the
  block and slide along the edge. For building up high.
- "Take all" in chests, next to "Store all".
- When crafting, what you can make with what you carry comes first.
- The first community furniture: the Pioneer's Trophy, for Cerberus Matos, the first to stream the game, and three
  paintings drawn by ZaikoSP. They're crafted at the workbench, and looking at them shows their dedication or
  signature.
- In Dark Cube, the sap flask can be crafted (empty flask + 4 leaves + 1 amber) and every sip leaves its empty flask.
- A tribute to Chama, the player Dark Cube was born for.

Fixes:
- The Creator's Workshop no longer drops to 4-7 FPS or stops loading terrain.
- Dark Cube: the roll dodges hits, but no longer poison, bleeding, burning or the environment.
- The Forge takes up both of its blocks.
- With big backpacks, the inventory no longer goes off screen: whatever doesn't fit scrolls.
- Boots stand on the ground and the left one is in place.
- The museum paintings are no longer mirrored.
- Status effects under your health (Burning, Poisoned...) are translated when the game is in English.
