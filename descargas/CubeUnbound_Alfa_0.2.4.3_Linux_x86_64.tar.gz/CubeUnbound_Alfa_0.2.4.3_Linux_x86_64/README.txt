CUBE UNBOUND · Alpha 0.2.4.3 for Linux (x86_64)
================================================

A voxel RPG on its own engine: explore, fight, find loot with rarities, level up, build,
tame mounts, trade and play with friends over LAN. It is an alpha: things are missing and
there will be bugs. Thanks for playing it!

The game is in English and Spanish. It picks your system language; you can change it in
Options > Language.

HOW TO START
------------
1. Unpack this folder wherever you like (nothing to install).
2. Run ./CubeUnbound (if it doesn't start, give it permission: chmod +x CubeUnbound).
3. Optional: ./instalar_acceso_directo.sh adds the game to your applications menu
   (./desinstalar_acceso_directo.sh removes it).

Requirements: a desktop with X11 or Wayland (through XWayland), OpenGL 3.3 (any graphics card
from the last 12 years with its drivers) and ALSA for sound (PulseAudio and PipeWire provide it).
Built with glibc 2.35: that version or newer (Ubuntu 22.04, Mint 21, Debian 12,
Fedora 36 or later). On an older one you only get "GLIBC_2.3x not found".

WHERE IT SAVES
--------------
Everything stays inside this folder: saves/ (worlds), characters/, settings.json (options),
screenshots/ and informes/ (the log of each session and crash reports). To back up your game
or move it to another PC, copy the whole folder.

PLAYING OVER LAN (same network)
-------------------------------
Whoever opens the game: "Host a LAN game" in the menu (or H inside your world). The others:
"Join a LAN game" and pick the game from the list, or type its IP. Windows, Android and Linux
play together. Everyone needs this same version (Alpha 0.2.4.3) and the same mods/ folder.

DEDICATED SERVER
----------------
./servidor.sh runs the game as a server, with no window. See LEEME_SERVIDOR.txt (in Spanish).
Console commands: list, say <text>, save, kick <name>, stop, help.

IF SOMETHING GOES WRONG
-----------------------
- If the game crashes, next time it opens it tells you: there is a report in informes/
  (fallo_<date>.txt). Send it to us, along with informes/registro.txt.
- If it runs slowly: Options > Graphics quality > Minimal or Low, and lower the view distance.

News and support: https://cubeunbound.com/

WHAT'S NEW IN 0.2.4.3
---------------------
0.2.4.3 brings CubeLord, the Waystone, flowing water and lava and, as a gift, the female body for all 10 races, and
fixes what you told us on Discord after 0.2.4.2. Thanks to everyone who reported. Your 0.2.4.2 worlds and character
open in 0.2.4.3 without losing anything.

New:
- CubeLord, the guide frog: lives by the well in the square of every village. Look at him and press E: he explains
  how to play (moving, fighting, levelling up, the inventory, villages, travelling, dungeons, playing with friends and
  shortcuts), with your own keys. He remembers what you have read.
- Waystone: travel from waystone to waystone. Crafted at the anvil (stone 30, gold ingot 6, crystal shard 8,
  magnetite 4, emerald 2). Travelling costs experience (it can take you down a level), you wait 5 minutes between
  trips and you can't travel mid-fight. Other players' waystones are discovered with E.
- The female body for all 10 races, as a gift: in the creator, "Body" (Male / Female).
- Water and lava flow: magma spreads 3 blocks (water, 7), with streaks, crusts, cracks and its own glow.
- The altimeter, the first information item (anvil: 2 copper ingots + 1 glass): carry it and the top left shows your
  height and which layer you're in.
- Shaped placeables: fences that join their neighbours, fence gate, thin glass, lattice, grate and bars with their
  models, and the corals, bamboo, abyssal mushroom, crystal spikes and lichen you place, with their models.
- Slabs and stairs in 5 materials: planks, cobblestone, stone, limestone brick and roof tiles.
- Every item shows its model in your hand and on the ground.

Fixes:
- The world far from the centre no longer shakes or loses its lighting.
- Fewer stutters with flowing water or magma and while hang-gliding.
- Copy and paste: Ctrl+V pastes into chat, the IP, the password and names; Ctrl+C copies the chat and the IP.
- Every death goes to the log with what you lost, and the informes folder keeps the last five sessions.
- The key help lines at the top left are gone.
- Torches no longer block you, and a lantern goes into the shield hand from a stack.
- City temples no longer give away zone 2 marble.

Multiplayer and servers:
- PvP on servers with "pvp" in servidor.json: free for all, with melee weapons and fists.
- On start the server says which world it is and when it was last saved, and warns if it's been long. If a server
  sends you an older copy of your character than the one you played, yours is kept aside and you don't join that
  time.
- Join by name even if your connection's DNS fails (the game asks 1.1.1.1 and 8.8.8.8).
- A world from a newer version is not saved (you're warned on entering), and old Intel HD graphics start with OpenGL.
- The network version changes: everyone needs 0.2.4.3 (and its mods folder) to play together.
