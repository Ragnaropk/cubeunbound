#!/bin/bash
# Cube Unbound · Servidor dedicado (como servidor.exe en Windows): abre el juego como servidor, sin ventana.
# Lo que pongas detrás se le pasa al juego (p. ej. --save-dir /otra/carpeta).
DIR=$(cd "$(dirname "$0")" && pwd)
cd "$DIR"
# Sin terminal (doble clic, el menú): se abre en una, para ver lo que pasa y contestar las preguntas de la primera vez
if [ ! -t 0 ] && [ -z "$CUBE_SERVIDOR_EN_TERMINAL" ] && [ -n "$DISPLAY$WAYLAND_DISPLAY" ]; then
    export CUBE_SERVIDOR_EN_TERMINAL=1
    for term in x-terminal-emulator gnome-terminal konsole xfce4-terminal mate-terminal lxterminal kitty alacritty xterm; do
        command -v "$term" > /dev/null || continue
        case "$term" in
            gnome-terminal) exec gnome-terminal -- "$DIR/servidor.sh" "$@" ;;
            *) exec "$term" -e "$DIR/servidor.sh" "$@" ;;
        esac
    done
fi
chmod +x "$DIR/CubeUnbound" 2>/dev/null
"$DIR/CubeUnbound" --server "$@"
code=$?
# Si se abrió una terminal sólo para esto, que no se cierre sin dejar leer el final
if [ -n "$CUBE_SERVIDOR_EN_TERMINAL" ]; then echo; read -r -p "Servidor cerrado. Pulsa Intro para salir. " _; fi
exit $code
