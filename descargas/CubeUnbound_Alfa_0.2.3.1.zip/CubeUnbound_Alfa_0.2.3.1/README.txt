CUBE UNBOUND · Alpha 0.2.3.1
==========================

A voxel RPG on its own engine: explore, fight, find loot with rarities, level up,
build, tame mounts, trade and play with friends over LAN.

This is an alpha: things are missing, there will be bugs and the numbers are still
being tuned. Thanks for playing it!

The game is in English and Spanish. It picks your Windows language; you can change it
in Options > Language.

WHAT'S NEW IN 0.2.3.1
---------------------
- Chests with loot: chests in villages, cities, camps, ruins and shipwrecks fill up the first time you open them, with
  items from that place and the zone's danger (further away, better loot, with rarity). They don't refill. Crypt
  chests in each dungeon also bring items found only there.
- Riding: R now mounts your pet even if it's a few steps away (before, standing still, it only said "Get closer").
  Next to a wild reindeer or horse, R tells you how to tame it.
- Boats are twice as fast; the sailboat no longer nearly stops against the wind.
- Keys no longer pile up: pressing O with the inventory open no longer opens the shop when you close it (same for
  any other shortcut).
- Your pet no longer pops up next to you while you glide, fly or ride a boat (it could knock you off the hang
  glider): it waits until you land.
- Tools in combat: hitting with a pickaxe, axe or shovel now goes at the pace of a fist (before they hit up to nine
  times as often, more than many swords). Mining blocks is as fast as before.
- Test keys (F3, F6, F7, F8 and F9) only work in developer mode and, on LAN, only for the host: before, anyone could
  push their gear to +20 with F7.
- Leaves placed next to dirt no longer let you see inside the ground.
- Seagrass and kelp can only be planted in water (outside they made water).
- Developer mode: the panel shows how far you are from the spawn point and the zone's danger.
- Worlds and characters from 0.2.3 work as they are. On LAN, everyone on 0.2.3.1.


WHAT'S NEW IN 0.2.3
-------------------
New:
- Torch: 1 stick + 1 coal make 4 (by hand). In your hand it lights up the area; press E to place it on the ground or
  next to a wall and it gives light. Stacks of 64.
- Flowing water: it spreads over the ground and runs down slopes. Bucket (anvil, 3 iron ingots): empty, right-click
  still water to fill it; full, right-click next to a block to pour it.
- Mining takes time: each block takes several hits depending on how hard it is and on your tool (a small bar under
  the crosshair shows your progress). A better pickaxe breaks faster. In creative, one hit.
- Chat commands (Enter and "/"): /help, /where, /seed and /cheats on. With cheats: /tp x y z (or bed, or spawn; "~"
  is where you are), /give item [n], /heal, /fly, /time, /weather and /creative. On LAN, for now only the host can
  use cheat commands.
- "Store all" in chests and wardrobes: moves your whole backpack into the chest (hotbar and gear stay).
- Player skins made in MagicaVoxel for the human: see mods/skins/LEEME.txt.
- Glass is see-through; the ladder has its own model against the wall.
- 49 more animals drop leather (fox, horse, lion, camel, sheep, mammoth...).

Fixed:
- Small screens (1024×768, narrow window): the crafting panel shows up again (and the bounty board and the
  merchant); the interface shrinks to fit.
- A boss health bar goes away after it has been far for a while (Ursa Major's stayed for hours).
- Uniques spawn at the zone's level (Tezcatl spawned at level 75 in zone 1); their usual level is the cap.
- The carriage no longer flies away.
- Pet names are accepted with Enter; you can ride it with R again and typing no longer triggers shortcuts.
- Bandits really defend their camp: they no longer turn back after a few blocks or ignore your hits.
- Combat music plays in real fights, not when hitting an animal or shooting into the air.
- Lanterns stack (before, one per slot) and no longer roll a rarity.
- LAN: a guest keeps their map of that world; someone who drops and rejoins no longer shows up twice; under the
  minimap you see which key closes the LAN (K).
- Discord with the game in English: the activity is fully in English.
- Worlds, characters and options from 0.2.2 work as they are. On LAN, everyone on 0.2.3.


WHAT'S NEW IN 0.2.2
-------------------
- FPS limit (Options > FPS limit: 30, 60, 90, 120, 144 or unlimited; 60 by default). Before, if the
  graphics driver or the desktop ignored vertical sync, the game drew as fast as it could: the GPU at
  100 % and the fans always on, especially on laptops and on Linux.
- With the window minimized or behind another one, the game drops to 15 FPS (30 on LAN) by itself.
- Laptops with two graphics chips (Intel + NVIDIA or AMD): the game uses the powerful one. Before it
  could stay on the integrated chip: low FPS and a lot of RAM used as video memory.
- If you pick Titan or Gods on integrated graphics, Options warns that it may run slowly.
- Discord: with Discord open, your profile shows that you are playing Cube Unbound, in which biome,
  with which race and level, solo or on LAN and for how long, with the "Download for free" and
  "Discord" buttons. Turn it off in Options > "Show activity on Discord".
- Poison, bleeding, burns and spell zones no longer drive creatures crazy: every frame used to count
  as a full hit (jerky movement, endless pain sounds, fleeing in random directions, zones throwing
  them far away). The damage is the same. On LAN, a player who joined sends that damage every half
  second instead of every frame.
- Worlds, characters and options from 0.2.1 work as they are. LAN works with 0.2.1, but it is best
  if everyone has 0.2.2.


WHAT'S NEW IN 0.2.1
-------------------
- English: menus, items, creatures and the guide (Options > Language).
- Chat: Enter to type, Enter to send. Messages show at the bottom left and in a bubble
  over the speaker's head. Hold Z for the sticker wheel. In servidor.exe, "say <text>".
- On LAN and with servidor.exe, creatures killed by a player who joined now fall to pieces
  at once (they used to stand for about 2 seconds). Best if everyone has this version.
- Special maps with mods: a mod can change the world's shape (island, flat, a small world
  with an edge, far zones closer, relief, climate, no caves or no villages) with
  mods/world/generation.json. The mod kit on the website does it without writing anything.
- A loading screen when the game starts: it no longer shows "Not responding" the first
  time, which is when it takes longest.
- Survival mode: you start with nothing. Tools, weapons and staves are found or crafted.
- The mouse wheel changes slot, like in Minecraft. Ctrl + wheel zooms the camera.
- Runs on Windows 7 SP1 and 8.1 too.
- The map is no longer mirrored: north up, east right. Map and minimap show N, S, E and W.
- Dungeons appear on the map when you pass near their entrance.
- Trash slot in the inventory, under the shield; the last thing thrown away can be
  recovered with a click.
- A lantern in your hand lights up around you (also in the off hand: Shift+click).
- Falling hurts less: up to about 5 blocks there is no damage.


HOW TO START
------------
1. Unzip the folder wherever you like (nothing to install). Use "Extract all":
   don't run the game from inside the zip.
2. Open CubeUnbound.exe.
3. "Character" to create yours and "Play" to start a world.
   The guide on the right tells you what to do in the first minutes.

Requirements: 64-bit Windows 7 SP1, 8.1, 10 or 11 and a graphics card with DirectX 11
or OpenGL 3.3. The first time, the game picks the graphics quality for your card;
change it in Options (Low if your PC struggles).


KEYS (change them in Options)
-----------------------------
  W A S D        walk               Space      jump (and open the glider in the air)
  Shift          run                Ctrl       crouch (to tame, with its food)
  Left click     hit / mine         Right click eat, charge the staff, use
  Tab            inventory and crafting        E   place / use (chests, beds, board, merchant)
  1-9            slots              Q          drop what you hold
  N              skill tree         R          mount or dismount
  M              map                J          codex (journal, achievements and titles)
  U              show or hide the guide        O   open your market stall
  Enter          chat               Z          sticker wheel (hold)
  T              rotate furniture   V          first or third person
  F5             save               F12        screenshot
  Esc            pause and options


WHERE IT SAVES
--------------
Everything stays inside this folder:
  saves\         worlds
  characters\    characters
  settings.json  options
  screenshots\   screenshots
  informes\      the log of each session and crash reports
To back up your game or move it to another PC, copy the whole folder.


PLAYING OVER LAN (same network)
-------------------------------
- Whoever opens the game: "Host a LAN game" in the menu (or H inside your world).
- The others: "Join a LAN game" and pick the game from the list.
- Everyone needs this same version (Alpha 0.2.1) and the same mods\ folder.
- Windows Firewall may ask the first time: allow private networks.


DEDICATED SERVER (servidor.exe)
-------------------------------
- servidor.exe runs the game as a server: no game window, just a console.
- The first time it asks for the world, the number of players (up to 7), the password
  (can be empty), the difficulty and PvP. Answers are kept in servidor.json.
- Console commands: list, say <text>, save, kick <name>, stop, help.
- Over the internet, forward UDP port 27015 to the server PC, or use a virtual network
  (Radmin VPN, ZeroTier).


IF SOMETHING GOES WRONG
-----------------------
- If the game crashes, next time it opens it tells you: there is a report in the
  informes\ folder (fallo_<date>.txt and .dmp). Send it to us.
- If something is off but the game keeps running: Esc > "Report a bug". It saves a
  screenshot, the log and your game in informes\informe_<date>\.
- If it runs slowly: Options > Graphics quality > Low, and lower the view distance.
- If it doesn't start or the screen is black: Options > Graphics at startup > OpenGL
  (or F11 in game to try the other one).

Contact: Neurostudios.contacto@gmail.com
