CUBE UNBOUND · Alpha 0.2.4.2 for Linux (x86_64)
================================================

A voxel RPG on its own engine: explore, fight, find loot with rarities, level up, build,
tame mounts, trade and play with friends over LAN. It is an alpha: things are missing and
there will be bugs. Thanks for playing it!

The game is in English and Spanish. It picks your system language; you can change it in
Options > Language.

HOW TO START
------------
1. Unpack this folder wherever you like (nothing to install).
2. Run ./CubeUnbound (if it doesn't start, give it permission: chmod +x CubeUnbound).
3. Optional: ./instalar_acceso_directo.sh adds the game to your applications menu
   (./desinstalar_acceso_directo.sh removes it).

Requirements: a desktop with X11 or Wayland (through XWayland), OpenGL 3.3 (any graphics card
from the last 12 years with its drivers) and ALSA for sound (PulseAudio and PipeWire provide it).
Built with glibc 2.35: that version or newer (Ubuntu 22.04, Mint 21, Debian 12,
Fedora 36 or later). On an older one you only get "GLIBC_2.3x not found".

WHERE IT SAVES
--------------
Everything stays inside this folder: saves/ (worlds), characters/, settings.json (options),
screenshots/ and informes/ (the log of each session and crash reports). To back up your game
or move it to another PC, copy the whole folder.

PLAYING OVER LAN (same network)
-------------------------------
Whoever opens the game: "Host a LAN game" in the menu (or H inside your world). The others:
"Join a LAN game" and pick the game from the list, or type its IP. Windows, Android and Linux
play together. Everyone needs this same version (Alpha 0.2.4.2) and the same mods/ folder.

DEDICATED SERVER
----------------
./servidor.sh runs the game as a server, with no window. See LEEME_SERVIDOR.txt (in Spanish).
Console commands: list, say <text>, save, kick <name>, stop, help.

IF SOMETHING GOES WRONG
-----------------------
- If the game crashes, next time it opens it tells you: there is a report in informes/
  (fallo_<date>.txt). Send it to us, along with informes/registro.txt.
- If it runs slowly: Options > Graphics quality > Minimal or Low, and lower the view distance.

News and support: https://cubeunbound.com/

WHAT'S NEW IN 0.2.4.2
---------------------
0.2.4.2 brings the paid game's vertical world to the free one, together with every fix you asked for on Discord and
in the forum. Thanks to everyone who reported them. Your 0.2.4.1 worlds and character open in 0.2.4.2: they keep their
surface block by block and gain everything below (a copy of the regions is saved first).

New:
- Vertical world, like the paid game: from −512 to +255. Below the surface, the giant mines (damp caves, crystal
  caverns, lava rivers and the abyss), more dangerous the deeper you go, with an unbreakable bottom.
  New worlds also get super mountain ranges, water-filled trenches and, at their bottom, the Blind Leviathan's Trench.
- Real doors in all 13 materials: E opens and closes them; closed, nobody gets through, monsters included.
- Wallet, like in Metin: copper, silver and gold no longer take backpack slots; they show above the panel.
- Split stacks with right click, like in Minecraft: with an empty cursor you take half; holding something, you drop one.
- Every item shows the level it requires ("Requires level N"; in yellow if you don't have it yet), and eating or
  taming something from a higher zone tells you the level you need.
- Skins on LAN and servers, and every player's name above their head.
- Sky events can finally be seen (aurora, comet, halo, eclipse, shooting stars), and they are much rarer.
- Controls: mouse buttons, Hit and Use can be rebound, Alt and F10, and a key already in use gets swapped.
  "Release the pet" has its own key (with no key, Shift+R twice).

Multiplayer and servers:
- Leaving a server and coming back puts you where you were, with your bed. Guests can tame.
- Joining a server on another version tells you so ("runs a newer/older version of the game").
- Buying from another player's stall: if you can't afford it, it tells you the price and what you have. New in
  servidor.json: startCoins (money for new characters) and sleepPercent (how many must sleep; "dormir 50" in the console).
- The servidor.exe console accepts hora, clima and invocar. The world takes its name from servidor.json.
- The network version changes: everyone needs 0.2.4.2 (and its mods folder) to play together.

World and fixes:
- The Ursa appears from danger 5 and raids follow the world's clock. Village chests give much less.
- The airship no longer clips into the terrain. Structures to the west (negative X) no longer show up as "City".
- Skull keys without exploits, crypt chests that fill when the boss falls, an exploration quest you can complete,
  and Sailor and Sea Dog count boarding a boat. The bed always shows at the workbench.
- No invisible water next to seaweed or water walls in rivers, and a lone door in the air no longer vanishes.
- Saving no longer freezes the game, and the loading problems list folds with F2.

