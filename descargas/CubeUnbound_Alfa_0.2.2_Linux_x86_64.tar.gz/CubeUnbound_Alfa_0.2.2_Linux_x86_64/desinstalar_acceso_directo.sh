#!/bin/bash
rm -f ~/.local/share/applications/cubeunbound.desktop
for n in 16 24 32 48 64 128 256 512; do rm -f ~/.local/share/icons/hicolor/${n}x${n}/apps/cubeunbound.png; done
echo "Quitado el acceso directo. El juego y tus partidas siguen en su carpeta."
