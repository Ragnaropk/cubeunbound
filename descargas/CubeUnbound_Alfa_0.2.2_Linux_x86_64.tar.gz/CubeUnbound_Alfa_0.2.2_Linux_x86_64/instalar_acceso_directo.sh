#!/bin/bash
# Pone el icono y el acceso directo de Cube Unbound en el menú del escritorio (solo para tu usuario).
# El juego sigue aquí: no copia nada más. Para quitarlo: desinstalar_acceso_directo.sh
set -e
DIR=$(cd "$(dirname "$0")" && pwd)
for n in 16 24 32 48 64 128 256 512; do
    mkdir -p ~/.local/share/icons/hicolor/${n}x${n}/apps
    cp "$DIR/icono/cubeunbound_$n.png" ~/.local/share/icons/hicolor/${n}x${n}/apps/cubeunbound.png
done
mkdir -p ~/.local/share/applications
sed "s|CUBE_DIR|$DIR|g" "$DIR/cubeunbound.desktop" > ~/.local/share/applications/cubeunbound.desktop
chmod +x "$DIR/CubeUnbound"
update-desktop-database ~/.local/share/applications 2>/dev/null || true
gtk-update-icon-cache ~/.local/share/icons/hicolor 2>/dev/null || true
echo "Listo: Cube Unbound está en el menú de aplicaciones (Juegos)."
